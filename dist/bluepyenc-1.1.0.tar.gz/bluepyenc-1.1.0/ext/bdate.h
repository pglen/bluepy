char *bdate="Sun Jan  4 03:11:46 2026";
